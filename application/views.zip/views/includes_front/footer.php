
  <!--===================Footer Section==================-->
            <div class="cs_footer_wrapper">
               <div class="container">
                  <div class="row" data-wow-duration="1.3s" style="visibility: visible; animation-duration: 0.8s; animation-name: slideInDown;">
                     <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                        <div class="cs_footer_section1">
                           <div class="cs_footer_logo">
                              <a href="<?php echo base_url();?>Dashboard/index/"><img src="<?php echo base_url();?>assets/images/index7/aapni_taxi1.png" style="height: 100px"></a>
                           </div>
                           <p>Apni Taxi is the center of the world! It is the glue of our daily lives.</p>
                           
                        </div>
                     </div>
                     <div class="col-lg-3 col-md-4 col-sm-6 col-12"></div>
                     <div class="col-lg-3 col-md-4 col-sm-6 col-12"></div>
                     <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                        <div class="cs_footer_section3">
                           <h5>Quick Links</h5>
                           <ul>
                              <li> <a href="<?php echo base_url();?>Dashboard/index/">Home</a></li>
                              <li> <a href="<?php echo base_url();?>Dashboard/about">About</a></li>
                              <li> <a href="<?php echo base_url();?>Dashboard/contact">Contact Us</a></li>
                              <li> <a href="<?php echo base_url();?>Dashboard/terms">Privacy Policy</a></li>
                              <li> <a href="<?php echo base_url();?>Dashboard/policy">Terms And Condition</a></li>
                           </ul>
                        </div>
                     </div>
                     
                  </div>
               </div>
               <div class="cs_copyright">
                  <p>Copyright © 2020 <a href="javascript:void(0);">Transport</a>. All Right Reserved.</p>
               </div>
            </div>
            <!-- GO To Top -->
            <a href="javascript:void(0);" id="scroll"><span class="fa fa-angle-double-up"></span></a>
            <!-- Script Start -->
             <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
            <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
            <script src="<?php echo base_url();?>assets/js/SmoothScroll.min.js"></script>
            <script src="<?php echo base_url();?>assets/js/swiper.min.js"></script>
            <script src="<?php echo base_url();?>assets/js/wow.min.js"></script>
            <script src="<?php echo base_url();?>assets/js/datepicker_moment.min.js"></script>
            <script src="<?php echo base_url();?>assets/js/datepicker.min.js"></script>
            <script src="<?php echo base_url();?>assets/js/custom.js"></script>
         </body>
      
<!-- Mirrored from kamleshyadav.com/html/transport/Index7/index_7.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 17 Feb 2022 20:15:54 GMT -->
</html>