<script src="<?php echo base_url(); ?>source/assets/plugins/jquery/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/plugins/popper/popper.min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/plugins/jquery-blockui/jquery.blockui.min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- bootstrap -->
<script src="<?php echo base_url(); ?>source/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/js/pages/sparkline/sparkline-data.js"></script>
<!-- Common js-->
<script src="<?php echo base_url(); ?>source/assets/js/app.js"></script>
<script src="<?php echo base_url(); ?>source/assets/js/layout.js"></script>
<script src="<?php echo base_url(); ?>source/assets/js/theme-color.js"></script>
<!-- material -->
<script src="<?php echo base_url(); ?>source/assets/plugins/material/material.min.js"></script>
<!-- animation -->
<script src="<?php echo base_url(); ?>source/assets/js/pages/ui/animations.js"></script>
<!-- morris chart -->
<script src="<?php echo base_url(); ?>source/assets/plugins/morris/morris.min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/plugins/morris/raphael-min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/js/pages/chart/morris/morris_home_data.js"></script>
<!-- google map -->
<script src="<?php echo base_url(); ?>source/assets/plugins/modernizr/modernizr.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAtPIcsjNx-GEuJDPmiXOVyB3G9k1eulX0&amp;callback=initMap" async defer></script>
<script src="<?php echo base_url(); ?>source/assets/js/pages/map/gmap-home.js"></script>
<script src="<?php echo base_url(); ?>source/assets/js/pages/extra_pages/login.js"></script>
<script src="<?php echo base_url(); ?>source/assets/plugins/flatpicker/js/flatpicker.min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/js/pages/datepicker/datetimepicker.js"></script>
<script src="<?php echo base_url(); ?>source/assets/plugins/datatables/datatables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>source/assets/js/pages/table/table_data.js"></script>
<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js" integrity="sha512-rMGGF4wg1R73ehtnxXBt5mbUfN9JUJwbk21KMlnLZDJh7BkPmeovBuddZCENJddHYYMkCh9hPFnPmS9sspki8g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>