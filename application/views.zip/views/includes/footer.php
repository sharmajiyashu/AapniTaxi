<div class="page-footer">
	<div class="page-footer-inner"> 2021 - 2022 &copy; Aapni Taxi by
		<a href="#" target="_top" class="makerCss">Premad Software Solutions</a>
	</div>
</div>