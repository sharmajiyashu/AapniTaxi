<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<?php include APPPATH. 'views/includes/css.php'; ?>
<!-- END HEAD -->

<style>
    .driver_detail{
        box-shadow: 2px 2px 2px 2px lightgray;
        padding: 20px 20px 20px 20px;
    }
</style>
<body
	class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-white">
	<div class="page-wrapper">
		<!-- start header -->
	<?php include APPPATH. 'views/includes/header.php'; ?>
		<!-- end header -->
		<!-- start page container -->
		<div class="page-container">
			<!-- start sidebar menu -->
	<?php include APPPATH. 'views/includes/sidebar.php'; ?>
			<!-- end sidebar menu -->
			<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Drivers</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="index-2.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Driver</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">All Drivers</li>
							</ol>
						</div>
					</div>
					<div class="tab-content tab-space">
						<div class="tab-pane active show" id="tab2">
							<div class="row">
							<?php if(isset($getData) && !empty($getData)){ ?>
								<div class="col-md-8 offset-2">
									<div class="card">
										<div class="m-b-20">
											<div class="doctor-profile">
												<div class="profile-header bg-b-purple">
												    <div class="row">
												    <div class="col-md-6">
												        <img src="<?php echo isset($getData['profile_pic']) ? base_url('pubilc/driver/').$getData['profile_pic'] : base_url().'source/assets/img/5444.jpg'; ?>" class="user-img" alt="" width="100px;" height="100px;" style="margin-top:20px;">
												    </div>
												    
												    <div class="col-md-6">
												        <div class="user-name"><?php echo strtoupper($getData['first_name']); ?><?php echo strtoupper($getData['last_name']); ?></div>
													<div class="name-center">0 Trips</div>
													<div class="col-md-12 col-sm-12 rating-style">
													    <!--<i class="material-icons">star</i>-->
													    <!--<i class="material-icons">star_half</i>-->
													    <i class="material-icons">star_border</i>
													    <i class="material-icons">star_border</i>
													    <i class="material-icons">star_border</i>
													    <i class="material-icons">star_border</i>
													    <i class="material-icons">star_border</i>
												    </div>
												    <div>
													<p style="color:black;">
														<i class="fa fa-phone"></i><a style="color:black;" href="tel:<?php echo isset($getData['mobile']) ? $getData['mobile'] : ''; ?>">
															<?php echo isset($getData['mobile']) ? $getData['mobile'] : ''; ?></a>
													</p>
												    </div>
												</div>
										    </div>
											</div>
											<div class="row" style="margin-top:30px;">
												<div class="col-md-6 driver_detail">
											       Permannent Address:
											       <br/>
											       Current Address
											    </div>
											    <div class="col-md-6">
											        <p class="driver_detail">
													<?php echo isset($getData['permanent_address']) ? strtoupper($getData['permanent_address']) : ''; ?> <br /><?php echo isset($getData['city']) ? strtoupper($getData['city']) : ''; ?>
												</p> 
											    </div>
											   
											    <div class="col-md-6"><p class="driver_detail">Total Cancelled Trip</p></div>
											    <div class="col-md-6"><p class="driver_detail">0</p></div>
											    
											    <div class="col-md-6"><p class="driver_detail">Total Revenue</p></div>
											    <div class="col-md-6"><p class="driver_detail">0</p></div>
											    
											    <div class="col-md-6"><p class="driver_detail">Total Commission Paid</p></div>
											    <div class="col-md-6"><p class="driver_detail">0</p></div>
											    </div>	
											</div>
										</div>
									</div>
								</div>
							<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end page content -->
		</div>
		<!-- end page container -->
		<!-- start footer -->
	<?php include APPPATH. 'views/includes/footer.php'; ?>
		<!-- end footer -->
	</div>
	<!-- start js include path -->
<?php include APPPATH. 'views/includes/js.php'; ?>
	<!-- end js include path -->
</body>
</html>