<?php

defined('BASEPATH') OR exit('No direct script access allowed');

Class Payment_Gateway extends MY_Model {

        public function saveUserPaymentInfo($user_id,$name,$email,$contact,$description,$payment_amount) {
        $data = array(  
            'user_id'=>$user_id,
            'name'=>isset($name) ? $name : '',
            'email'=> isset($email) ? $email : '',
            'contact'=> isset($contact) ? $contact : '',
            'payment_amount'=> isset($payment_amount) ? ($payment_amount/100) : '',
            'description'=> isset($description) ? $description : '',
            'status' => 'Pending',
            'created_at'=> date('Y-m-d h:i:s'),
            'updated_at'=> date('Y-m-d h:i:s'),
        );
        $this->db->insert('payment_history', $data);
        $save = $this->db->insert_id();
        if ($save > 0) {
            return  $save;
        } else {         
            return  false;
        }
    }
    
    public function PayNow($postData) {
        extract($postData);
        $id = isset($postData['payment_id']) ? $postData['payment_id'] : '';
        if($postData['status_code'] == 200){
            $data = array(  
                'txn_id'=> isset($postData['razorpay_payment_id']) ? $postData['razorpay_payment_id'] : '',
                'payment_mode' => isset($postData['payment_method']) ? $postData['payment_method'] : '',
                'status' =>  'TXN_SUCCESS',
                'txn_date'=>   date('Y-m-d h:i:s'),
                'created_at'=> date('Y-m-d h:i:s'),
                'updated_at'=> date('Y-m-d h:i:s'),
            );
            $this->db->where('id',$id)->update('payment_history', $data);
        }else{
            $data = array(  
                'txn_id'=> isset($postData['razorpay_payment_id']) ? $postData['razorpay_payment_id'] : '',
                'payment_mode' => isset($postData['payment_method']) ? $postData['payment_method'] : '',
                'status' =>  'TXN_FAILURE',
                'txn_date'=>   date('Y-m-d h:i:s'),
                'created_at'=> date('Y-m-d h:i:s'),
                'updated_at'=> date('Y-m-d h:i:s'),
            );
            $this->db->where('id',$id)->update('payment_history', $data); 
        }
        if ($id > 0) {
            return  $id;
        } else {         
            return  false;
        }
    }
}
