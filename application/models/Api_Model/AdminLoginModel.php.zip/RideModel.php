<?php

defined('BASEPATH') OR exit('No direct script access allowed');

Class RideModel extends CI_Model {


    public function getAllDestination($user_id) {
        $this->db->where('user_id',$user_id); 
        $this->db->select('address_destination');
        $this->db->order_by('id','desc');
        $query = $this->db->get('cab_ride');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        } else {         
            return  false;
        }
    }
    
    
    public function checkDriverRide($rideId,$driverId) {
        $this->db->where('id',$rideId); 
        $this->db->where('driver_id',$driverId); 
        $query = $this->db->get('cab_ride');
        if ($query->num_rows() > 0) {
            return  $query->num_rows();
        } else {         
            return  false;
        }
    }
    
    public function updateRideLocationStatus($postData){
        extract($postData);
        $rideId = isset($ride_id) ? $ride_id : '';
        $driverId = isset($driver_id) ? $driver_id : '';
        // chek location status
        $chekLocationStatus = $this->db->where('id',$rideId); 
        $this->db->where('driver_id',$driverId); 
        $query = $this->db->get('cab_ride')->row_array();
        // if($query['location_status'] == 0){
        //     $location_status = 1;
        // }else if($query['location_status'] == 1){
        //     $location_status = 2;
        // }else if($query['location_status'] == 2){
        //     $location_status = 2;
        // }
        
        $data = array(
            'updated_type'=>'Driver',
            'updated_at'=>date('Y-m-d h:i:s'),
            'updated_by'=> $driverId,
            'location_status'=> isset($location_status) ? $location_status : '',
            );
        $update = $this->db->where('id', $rideId)
        ->update('cab_ride', $data);
        if($update){
           $responce = $this->getRiderDetail($rideId);
           return $responce;
        }else{
            return array();
        }
    }
    
    public function getRiderDetail($ride) {
        
        $this->db->select('cr.id,cr.driver_id,cr.per_km_price,cr.user_id,cr.cab_id,cr.cab_type,cr.otp,cr.otp_status,cr.distance,cr.estimated_time,cr.source_latitude,cr.source_longitude,cr.destination_latitude,cr.destination_longitude,cr.canceled,cr.canceled_type,cr.canceled_reason,cr.vechicle_name,cr.price,cr.per_km_price,cr.status,cr.location_status,cr.updated_type, d.mobile as driver_mobile, c.registration_number as cab_number, c.cab_category_name as cab_name, CONCAT(d.first_name, " ",'.', d.last_name) AS driver_name', FALSE );
        $this->db->from('cab_ride as cr');
        $this->db->join('driver as d','d.id = cr.driver_id','left');
        $this->db->join('cab as c','c.id = cr.cab_id');
        $this->db->where('cr.id',$ride); 
        $query = $this->db->get('cab_ride');
        
        $data = $query->row_array();
        if ($query->num_rows() > 0) {
            $sourceLocation = array('latitude'=>$data['source_latitude'],'longitude'=>$data['source_longitude']);
            $destinationLocation = array('latitude'=>$data['destination_latitude'],'longitude'=>$data['destination_longitude']);
            return $output = array(
                    'sourceLocation' => $sourceLocation,
                    'destinationLocation' => $destinationLocation,
                    'rideData' => $data,
                );
        } else {         
            return  array();
        }
    }
    
    public function updateDastination($postdata,$distances,$farPrice) {
        extract($postdata);
        $data = array(
                        'destination_latitude'=>  isset($destination_latitude) ? $destination_latitude   : '',
                        'destination_longitude'=> isset($destination_longitude) ? $destination_longitude : '',
                        'distance'=>$distances,
                        'price'=>$farPrice,
                        'updated_at'=>date('Y-m-d h:i:s'),
                        'updated_type'=>'Driver',
                        'updated_by'=> isset($driver_id) ? $driver_id : ''
        );
        $this->db->where('id',$ride_id);
        $update = $this->db->update('cab_ride', $data);
        if ($update) {
            return  true;
        } else {         
            return  false;
        }
    }
    
    
    public function rideBookingOtpVerify($postdata) {
        extract($postdata);
        $this->db->where('id',$ride_id);
        $this->db->where('driver_id',$driver_id);
        $this->db->where('otp',$otp); 
        $query = $this->db->get('cab_ride');
        if ($query->num_rows() > 0){
        $this->db->where('id',$ride_id);
        $this->db->where('driver_id',$driver_id);
        $this->db->where('otp',$otp); 
        $update = $this->db->update('cab_ride', ['otp_status'=>1,'updated_at'=>date('Y-m-d h:i:s'),'updated_by'=>$driver_id]);
            return  $query->result_array();
        } else {         
            return  false;
        }
    }
    
        public function getDriverBookings($driver_id) {
        
        $data = $this->db->select('CONCAT(u.first_name," ", ' .' , u.last_name) as username,u.mobile,r.otp,r.distance,r.source_latitude,r.source_longitude,r.destination_latitude,r.destination_longitude,r.price,r.id as ride_id,u.user_id,r.canceled')
        ->from('cab_ride as r')
        ->join('users as u','u.user_id = r.user_id')
        ->where('r.driver_id',$driver_id)
        ->order_by('r.id','desc')
        ->get()->row_array();
        if ($data) {
            $data2 = array('username'=>$data['username'],'otp'=>$data['otp'],'mobile'=>$data['mobile'],'fare_price'=>$data['price'],'id'=>$data['ride_id'],'user_id'=>$data['user_id'],'canceled' => $data['canceled']);
            $sourceLocation = array('latitude'=>$data['source_latitude'],'longitude'=>$data['source_longitude']);
            $destinationLocation = array('latitude'=>$data['destination_latitude'],'longitude'=>$data['destination_longitude']);
            
            return $output = array(
                    'sourceLocation' => $sourceLocation,
                    'destinationLocation' => $destinationLocation,
                    'otherData' => $data2,
                );
            
        } else {         
            return  array();
        }
    }
        
        function getCabNearBy($postData){
            extract($postData);
            $query = $this->db->query("SELECT ucl.* FROM user_current_locations as ucl INNER JOIN driver on ucl.user_id = driver.id INNER JOIN cab on driver.id = cab.driver_id WHERE ucl.user_type = 'Driver' AND driver.driver_current_status = 'online' AND cab.cab_type_id = $cab_type");
            if($query->num_rows() > 0){
              return $query->result_array();
            }else{
              return false;
            }
        }
    
    
        function getAllCabThisCategory($cab_type_id){
            $this->db->where('user_type','Driver');
            $this->db->where('cab_type_id',$cab_type_id);
            $data =$this->db->get('user_current_locations')->result_array();        
            return $data;
        }
        
        function getCabCurrentLocation($driver_id){
            $this->db->where('user_type','Driver');
            $this->db->where('user_id',$driver_id);
            $data =$this->db->get('user_current_locations')->row_array();        
            return $data;
        }
    
    
    
     public function getFarCityWise($city) {
        
        $this->db->where('a_c_f_p.citi_name',$city);
        $this->db->select('a_c_f_p.*,  cc.cab_icon');
        $this->db->from('all_cab_far_price as a_c_f_p');
        $this->db->join('cab-category as cc','cc.id = a_c_f_p.vehicle_category');
        $this->db->group_by('a_c_f_p.vehicle_category');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        } else {         
            return  false;
        }
    }
    
     public function getFarStateWise($state) {
        
        $this->db->where('a_c_f_p.state_name',$state);
        $this->db->select('a_c_f_p.*,  cc.cab_icon');
        $this->db->from('all_cab_far_price as a_c_f_p');
        $this->db->join('cab-category as cc','cc.id = a_c_f_p.vehicle_category');
        $this->db->group_by('a_c_f_p.vehicle_category');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        } else {         
            return  $query->result_array();
        }
    }
    
    
    public function getLastRideDetail($user_id) {
        
        $this->db->where('user_id',$user_id);        
        $this->db->order_by('id','desc');
        $this->db->limit(1);
        $query = $this->db->get('cab_ride');
        if ($query->num_rows() > 0) {
            return  $query->row_array();
        } else {         
            return  false;
        }
    }

    public function saveRide($postdata,$cab_data) {
        
        $this->db->insert('json_test',['data'=>json_encode($_POST)]);
        extract($postdata);
        
        $otp = rand(1000,9999);
        $distances = isset($cab_data['distance']) ? $cab_data['distance'] : '';
        $final_distance = str_replace(" km","",$distances);
        
        $driver_id = isset($cab_data['driver_id']) ? $cab_data['driver_id'] : '';
        $cab_id =    isset($cab_data['cab_id']) ? $cab_data['cab_id'] : '';
        $data = array(
        'user_id'=>isset($user_id) ? $user_id : '',
        'driver_id'=>$driver_id,
        'estimated_time'=>isset($estimated_time) ? $estimated_time : '',
        'cab_id'=>$cab_id,
        'cab_type'=>isset($cab_type) ? $cab_type : '',
        'source_latitude'=>isset($source_latitude) ? $source_latitude : '',
        'source_longitude'=>isset($source_longitude) ? $source_longitude : '',
        'destination_latitude'=>isset($destination_latitude) ? $destination_latitude : '',
        'destination_longitude'=>isset($destination_longitude) ? $destination_longitude : '',
        'ride_start_time'=>isset($ride_start_time) ? $ride_start_time : '',
        // 'ride_end_time'=>isset($ride_end_time) ? $ride_end_time : '',
        'price'=>isset($price) ? $price : '',
        'distance'=>isset($final_distance) ? $final_distance : '',
        'vechicle_name'=>isset($vechicle_name) ? $vechicle_name : '',
        'created_at'=>date('Y-m-d h:i:s'),
        'updated_at'=>date('Y-m-d h:i:s'),
        'created_by'=> isset($user_id) ? $user_id : '',
        'updated_by'=> isset($user_id) ? $user_id : '',
        'otp'=> $otp,
        );
        // debug($data);die;
        $this->db->insert('cab_ride', $data);
        $insert = $this->db->insert_id();
        // echo $insert;die;
        if ($insert > 0) {
            // echo $cab_id;die;
            $driverDetail = $this->getDriverDetail($driver_id);
            // print_r($driverDetail);die;
            $cabDetail = $this->getCabDetail($cab_id);
            // print_r($cabDetail);die;
            $first_name = isset($driverDetail['first_name']) ? $driverDetail['first_name'] : '';
            $last_name = isset($driverDetail['last_name']) ? $driverDetail['last_name'] : '';
            $driver_name = $first_name.' '.$last_name;
            $save_ride =  array(
                'driver_id'=>$driver_id,
                'driver_name'=>$driver_name,
                'mobile'=> isset($driverDetail['mobile']) ? $driverDetail['mobile'] : '',
                'cab_id'=>isset($cabDetail['id']) ? $cabDetail['id'] : '',
                'cab_name'=> isset($cabDetail['cab_model_name']) ? $cabDetail['cab_model_name'] : '',
                'cab_number'=> isset($cabDetail['registration_number']) ? $cabDetail['registration_number'] : '',
                'ride_id'=> isset($insert) ? $insert : '',
                'otp'=> $otp
                );
                 return $save_ride;
        } else {         
            return  false;
        }
    }
    
    public function getDriverDetail($id) {        
		$this->db->where('id',$id);
		$query = $this->db->get('driver');
		if ($query->num_rows() > 0) {
			return  $query->row_array();
		} else {         
			return  false;
		}
	}
	
	public function getCabDetail($id) {        
		$this->db->where('id',$id);
		$query = $this->db->get('cab');
		if ($query->num_rows() > 0) {
			return  $query->row_array();
		} else {         
			return  false;
		}
	}
    
    public function cancelRide($postdata) {
        extract($postdata);
        $data = array(
            'canceled_type'=> isset($postdata['canceled_type']) ? $postdata['canceled_type'] : '',
            'canceled_reason'=> isset($canceled_reason) ? $canceled_reason : '',
            'canceled'=>1,
            'updated_at'=>date('Y-m-d h:i:s'),
            'updated_by'=> isset($postdata['id']) ? $postdata['id'] : ''
        );
    
        $this->db->where('id',$postdata['ride_id']);
        $update = $this->db->update('cab_ride', $data);
        
        if ($update) {
            return  true;
        } else {         
            return  false;
        }
    }
    
    public function checkDriveOnline(){
      $data = $this->db->where('driver_current_status','online')->get('driver')->num_rows();
      if($data > 0){
        return true;
      }else{
        return false;
      }
    }
    
    public function rideHistory($postData){
      extract($postData);
      $query = $this->db->query('SELECT cab_ride.distance, cab_ride.price, cab_ride.created_at , driver.first_name, driver.last_name FROM `cab_ride` INNER JOIN driver ON cab_ride.driver_id = driver.id WHERE user_id ='.$id)->result_array();
      if($query > 0){
        return $query;
      }else{
          return false;
      }
    }
    
    public function sos($postData){
        extract($postData);
        $data = array(
          'user_id' => isset($user_id) ? $user_id : '',
          'driver_id' => isset($driver_id) ? $driver_id : '',
          'latitude' => isset($latitude) ? $latitude  : '',
          'longitude' => isset($longitude) ? $longitude : '',
          'created_at' => date('Y-m-d h:i:s')
        );
        $this->db->insert('sos',$data);
        $lastInsertId = $this->db->insert_id();
        if($lastInsertId != ''){
            return $lastInsertId;
        }else{
            return false;
        }
    }
    
    
}
