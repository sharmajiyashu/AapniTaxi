<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		if($this->session->userdata('type') != 'Superadmin')
			redirect('admin/Login');		
	}
	
	public function index()
	{
	    $data['driver'] = $this->db->get('driver')->num_rows();
	    $data['ride_online'] = $this->db->where('driver_current_status','online')->get('driver')->num_rows();
	    $data['ride'] = $this->db->get('cab_ride')->num_rows();
	    $data['user'] = $this->db->get('users')->num_rows();
		$this->load->view('admin/dashboard',['data' => $data]);
	}
}
