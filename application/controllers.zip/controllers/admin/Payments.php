<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payments extends CI_Controller {

	
	public function __construct(){
		parent::__construct();
		if($this->session->userdata('type') != 'Superadmin')
			redirect('admin/Login');
	}
	
	public function listPayments(){
	    $alldata = $this->db->get('payment_history')->result_array();
	    $data = $this->db->get('gst-commission')->row_array();
	    $new_arr = array();
	    foreach($alldata as $key => $value){
	      
	        $name = $this->db->where('user_id',$value['user_id'])->get('users')->row_array();
	        $first_name = isset($name['first_name'])  ? $name['first_name'] : '';
	        $last_name = isset($name['last_name'])  ? $name['last_name'] : '';
	        $Uname = $first_name.$last_name;
	        
	        $name1 = $this->db->where('id',$value['driver_id'])->get('driver')->row_array();
	        $first_name1 = isset($name1['first_name'])  ? $name1['first_name'] : '';
	        $last_name1 = isset($name1['last_name'])  ? $name1['last_name'] : '';
	        $Dname = $first_name1.$last_name1;
	      
	      $new_arr[$key] = $value;
	      $new_arr[$key]['username'] =  $Uname;
	      $new_arr[$key]['drivername'] =  $Dname;
	      $commission = ($value['payment_amount'] * (double)$data['commission'])/100;
	      $gst = ($value['payment_amount'] * (double)$data['gst'])/100;
	      $new_arr[$key]['commission'] =  $commission;
	      $new_arr[$key]['gst'] =  $gst;
	      $new_arr[$key]['total_balance'] =  ($value['payment_amount'] + $commission + $gst); 
	    }
	    $this->load->view('admin/list-payment',['data' => $new_arr]);
	}
}